import React from 'react';

const Login = () => {
  return (
    <div className="max-w-md mx-auto mt-8">
      <h2 className="text-2xl font-bold mb-4">Login</h2>
      <form className="space-y-4">
        <div>
          <label className="block mb-1">Email</label>
          <input type="email" className="input-field" />
        </div>
        <div>
          <label className="block mb-1">Password</label>
          <input type="password" className="input-field" />
        </div>
        <button type="submit" className="btn-primary w-full">
          Login
        </button>
      </form>
    </div>
  );
};

export default Login; 