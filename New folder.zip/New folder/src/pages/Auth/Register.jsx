import React from 'react';

const Register = () => {
  return (
    <div className="max-w-md mx-auto mt-8">
      <h2 className="text-2xl font-bold mb-4">Register</h2>
      <form className="space-y-4">
        <div>
          <label className="block mb-1">Name</label>
          <input type="text" className="input-field" />
        </div>
        <div>
          <label className="block mb-1">Email</label>
          <input type="email" className="input-field" />
        </div>
        <div>
          <label className="block mb-1">Password</label>
          <input type="password" className="input-field" />
        </div>
        <button type="submit" className="btn-primary w-full">
          Register
        </button>
      </form>
    </div>
  );
};

export default Register; 