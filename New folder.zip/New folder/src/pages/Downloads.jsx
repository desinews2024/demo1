import React from 'react';

const Downloads = () => {
  return (
    <div className="container mx-auto px-4">
      <h1 className="text-3xl font-bold mb-6">My Downloads</h1>
      <div className="space-y-4">
        {/* Add download items here */}
      </div>
    </div>
  );
};

export default Downloads; 